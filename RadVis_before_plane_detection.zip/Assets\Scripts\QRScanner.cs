using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using ZXing;
using ZXing.Common;

#if UNITY_ANDROID && !UNITY_EDITOR
using UnityEngine.Android;
#endif

/// <summary>
/// Opens the Beam Pro / Android device camera inside Unity and scans QR codes.
/// Attach this script to the existing QRScanner GameObject.
/// </summary>
public class QRScanner : MonoBehaviour
{
    public delegate void FNotifyDetectorNameSignature(string inText);
    public static event FNotifyDetectorNameSignature OnQRDetected;

    public delegate void FNotifyQRDetectedDetailedSignature(
        string qrText,
        Vector2 imageCenter,
        int imageWidth,
        int imageHeight,
        float qrPixelSize
    );
    public static event FNotifyQRDetectedDetailedSignature OnQRDetectedDetailed;

    [Header("UI")]
    [SerializeField] private RawImage cameraPreview;
    [SerializeField] private TMP_Text statusText;
    [SerializeField] private Button scanButton;
    [SerializeField] private Button stopButton;

    [Header("Camera")]
    [SerializeField] private bool preferRearCamera = true;
    [SerializeField] private int requestedWidth = 1280;
    [SerializeField] private int requestedHeight = 720;
    [SerializeField] private int requestedFPS = 30;

    [Header("Scan")]
    [SerializeField] private float scanInterval = 0.25f;
    [SerializeField] private bool autoStopAfterFirstResult = true;
    [SerializeField] private bool ignoreDuplicateQr = false;
    [SerializeField] private bool allowRescanSameQrToUpdatePosition = true;

    public List<string> detectorNameList = new List<string>();

    public string LastQrText { get; private set; }
    public Vector2 LastQrCenterInImage { get; private set; }
    public int LastImageWidth { get; private set; }
    public int LastImageHeight { get; private set; }
    public float LastQrPixelSize { get; private set; }

    private WebCamTexture camTexture;
    private Coroutine scanCoroutine;
    private bool isStarting;
    private bool isScanning;

    private void Start()
    {
        if (scanButton != null)
            scanButton.onClick.AddListener(StartScanning);

        if (stopButton != null)
            stopButton.onClick.AddListener(StopScanning);

        SetPreviewVisible(false);
        UpdateStatus("QR scan ready");
    }

    public void StartScanning()
    {
        if (isStarting || isScanning)
            return;

        StartCoroutine(RequestPermissionAndStartCamera());
    }

    public void StopScanning()
    {
        isStarting = false;
        isScanning = false;

        if (scanCoroutine != null)
        {
            StopCoroutine(scanCoroutine);
            scanCoroutine = null;
        }

        if (camTexture != null)
        {
            if (camTexture.isPlaying)
                camTexture.Stop();

            Destroy(camTexture);
            camTexture = null;
        }

        SetPreviewVisible(false);
    }

    private IEnumerator RequestPermissionAndStartCamera()
    {
        isStarting = true;
        UpdateStatus("Requesting camera permission...");

#if UNITY_ANDROID && !UNITY_EDITOR
        if (!Permission.HasUserAuthorizedPermission(Permission.Camera))
        {
            Permission.RequestUserPermission(Permission.Camera);

            float permissionWaitTime = 0f;
            while (!Permission.HasUserAuthorizedPermission(Permission.Camera) && permissionWaitTime < 10f)
            {
                permissionWaitTime += Time.deltaTime;
                yield return null;
            }
        }
#endif

        yield return Application.RequestUserAuthorization(UserAuthorization.WebCam);

        if (!Application.HasUserAuthorization(UserAuthorization.WebCam))
        {
            isStarting = false;
            UpdateStatus("Camera permission denied");
            Debug.LogError("Camera permission denied.");
            yield break;
        }

        yield return StartCoroutine(StartCamera());
    }

    private IEnumerator StartCamera()
    {
        WebCamDevice[] devices = WebCamTexture.devices;

        if (devices == null || devices.Length == 0)
        {
            isStarting = false;
            UpdateStatus("No camera found");
            Debug.LogError("No WebCamTexture camera found.");
            yield break;
        }

        WebCamDevice selectedDevice = devices[0];

        for (int i = 0; i < devices.Length; i++)
        {
            Debug.Log($"Camera[{i}] name={devices[i].name}, isFrontFacing={devices[i].isFrontFacing}");

            if (preferRearCamera && !devices[i].isFrontFacing)
            {
                selectedDevice = devices[i];
                break;
            }
        }

        camTexture = new WebCamTexture(selectedDevice.name, requestedWidth, requestedHeight, requestedFPS);
        camTexture.Play();

        float waitTime = 0f;
        while (camTexture.width <= 16 && waitTime < 3f)
        {
            waitTime += Time.deltaTime;
            yield return null;
        }

        if (camTexture.width <= 16)
        {
            isStarting = false;
            UpdateStatus("Camera failed to start");
            Debug.LogError("Camera failed to start.");
            StopScanning();
            yield break;
        }

        if (cameraPreview != null)
        {
            cameraPreview.texture = camTexture;
            cameraPreview.rectTransform.localEulerAngles = new Vector3(0f, 0f, -camTexture.videoRotationAngle);

            if (camTexture.videoVerticallyMirrored)
                cameraPreview.uvRect = new Rect(0f, 1f, 1f, -1f);
            else
                cameraPreview.uvRect = new Rect(0f, 0f, 1f, 1f);
        }

        SetPreviewVisible(true);

        isStarting = false;
        isScanning = true;
        scanCoroutine = StartCoroutine(ScanLoop());

        UpdateStatus($"Camera on: {selectedDevice.name}\nPoint camera at QR code");
        Debug.Log($"QR camera started: {selectedDevice.name}, size={camTexture.width}x{camTexture.height}");
    }

    private IEnumerator ScanLoop()
    {
        while (isScanning)
        {
            ScanFrame();
            yield return new WaitForSeconds(scanInterval);
        }
    }

    private void ScanFrame()
    {
        if (camTexture == null || !camTexture.isPlaying)
            return;

        if (camTexture.width <= 16 || camTexture.height <= 16)
            return;

        try
        {
            Color32[] pixels = camTexture.GetPixels32();
            byte[] bytes = new byte[pixels.Length * 4];

            for (int i = 0; i < pixels.Length; i++)
            {
                int index = i * 4;
                bytes[index] = pixels[i].r;
                bytes[index + 1] = pixels[i].g;
                bytes[index + 2] = pixels[i].b;
                bytes[index + 3] = pixels[i].a;
            }

            RGBLuminanceSource source = new RGBLuminanceSource(
                bytes,
                camTexture.width,
                camTexture.height,
                RGBLuminanceSource.BitmapFormat.RGBA32
            );

            HybridBinarizer binarizer = new HybridBinarizer(source);
            BinaryBitmap bitmap = new BinaryBitmap(binarizer);
            ZXing.QrCode.QRCodeReader reader = new ZXing.QrCode.QRCodeReader();
            Result result = reader.decode(bitmap);

            if (result == null || string.IsNullOrWhiteSpace(result.Text))
                return;

            string qrText = result.Text.Trim();
            bool alreadyScanned = detectorNameList.Contains(qrText);

            if (alreadyScanned && ignoreDuplicateQr && !allowRescanSameQrToUpdatePosition)
            {
                UpdateStatus($"Already scanned: {qrText}");
                if (autoStopAfterFirstResult)
                    StopScanning();
                return;
            }

            LastQrText = qrText;
            LastQrCenterInImage = CalculateCenter(result.ResultPoints);
            LastImageWidth = camTexture.width;
            LastImageHeight = camTexture.height;
            LastQrPixelSize = CalculateQrPixelSize(result.ResultPoints);

            if (!alreadyScanned)
                detectorNameList.Add(qrText);

            Debug.Log($"QR detected: {qrText}, center={LastQrCenterInImage}, image={LastImageWidth}x{LastImageHeight}, qrPixelSize={LastQrPixelSize:F1}");
            UpdateStatus($"QR detected\n{qrText}\nX:{LastQrCenterInImage.x:F0} Y:{LastQrCenterInImage.y:F0}");

            OnQRDetected?.Invoke(qrText);
            OnQRDetectedDetailed?.Invoke(qrText, LastQrCenterInImage, LastImageWidth, LastImageHeight, LastQrPixelSize);

            if (autoStopAfterFirstResult)
                StopScanning();
        }
        catch (ReaderException)
        {
            // This is normal when there is no QR code in the camera image.
        }
        catch (System.Exception e)
        {
            Debug.LogError($"QR scan error: {e.Message}");
        }
    }

    private Vector2 CalculateCenter(ResultPoint[] points)
    {
        if (points == null || points.Length == 0)
            return new Vector2(camTexture.width * 0.5f, camTexture.height * 0.5f);

        float sumX = 0f;
        float sumY = 0f;

        for (int i = 0; i < points.Length; i++)
        {
            sumX += points[i].X;
            sumY += points[i].Y;
        }

        return new Vector2(sumX / points.Length, sumY / points.Length);
    }

    private float CalculateQrPixelSize(ResultPoint[] points)
    {
        if (points == null || points.Length < 2)
            return 0f;

        float maxDistance = 0f;
        for (int i = 0; i < points.Length; i++)
        {
            for (int j = i + 1; j < points.Length; j++)
            {
                float distance = Vector2.Distance(
                    new Vector2(points[i].X, points[i].Y),
                    new Vector2(points[j].X, points[j].Y)
                );

                if (distance > maxDistance)
                    maxDistance = distance;
            }
        }

        // With three QR points, the longest line is often a diagonal.
        // Divide by sqrt(2) to get a rough side length in pixels.
        return maxDistance / 1.41421356f;
    }

    private void SetPreviewVisible(bool visible)
    {
        if (cameraPreview != null)
            cameraPreview.gameObject.SetActive(visible);
    }

    private void UpdateStatus(string message)
    {
        if (statusText != null)
            statusText.text = message;

        Debug.Log(message);
    }

    private void OnDestroy()
    {
        StopScanning();
    }
}
