using System.Collections.Generic;
using NativeWebSocket;
using Newtonsoft.Json.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class RadiationReceiver : MonoBehaviour
{
    [SerializeField] private TMP_Text displayText;
    [SerializeField] private TMP_InputField ipInputField;  // IP 입력창
    [SerializeField] private Button connectButton;          // 연결 버튼
    [SerializeField] private TMP_Text statusText;           // 연결 상태 표시

    private WebSocket websocket;
    private string savedIp = "192.168.0.60"; // 마지막으로 사용한 IP

    void Start()
    {
        // 저장된 IP 불러오기
        savedIp = PlayerPrefs.GetString("ServerIP", "192.168.0.60");
        ipInputField.text = savedIp;

        connectButton.onClick.AddListener(OnConnectButtonClicked);
        UpdateStatus("Disconnected", Color.red);
    }

    void OnConnectButtonClicked()
    {
        string ip = ipInputField.text.Trim();
        if (string.IsNullOrEmpty(ip)) return;

        // IP 저장
        PlayerPrefs.SetString("ServerIP", ip);
        PlayerPrefs.Save();

        Connect(ip);
    }

    async void Connect(string ip)
    {
        Debug.Log($"Trying connecting to URL: ws://{ip}:5002");
        // 기존 연결 끊기
        if (websocket != null && websocket.State == WebSocketState.Open)
            await websocket.Close();

        string url = $"ws://{ip}:5002";
        UpdateStatus($"Connecting to... {url}", Color.yellow);

        websocket = new WebSocket(url);

        websocket.OnOpen += () =>
        {
            Debug.Log("Server connected!");
            UnityMainThreadDispatcher.Enqueue(() =>
                UpdateStatus($"Connected: {ip}", Color.green));
        };

        websocket.OnMessage += (bytes) =>
        {
            string json = System.Text.Encoding.UTF8.GetString(bytes);
            Debug.Log($"Received data: {json}");

            var root = JObject.Parse(json);
            var dict = root["deviceDataDictionary"].ToObject<Dictionary<string, float>>();

            string result = "";
            foreach (var kvp in dict)
                result += $"Device: {kvp.Key}  Radiation: {kvp.Value}\n";

            UnityMainThreadDispatcher.Enqueue(() =>
                displayText.text = result);
        };

        websocket.OnError += (e) =>
        {
            Debug.LogError($"Error: {e}");
            UnityMainThreadDispatcher.Enqueue(() =>
                UpdateStatus($"Error: {e}", Color.red));
        };

        websocket.OnClose += (e) =>
        {
            Debug.Log("Disconnected");
            UnityMainThreadDispatcher.Enqueue(() =>
                UpdateStatus("Disconnected", Color.red));
        };

        await websocket.Connect();
    }

    void UpdateStatus(string message, Color color)
    {
        if (statusText != null)
        {
            statusText.text = message;
            statusText.color = color;
        }
    }

    void Update()
    {
#if !UNITY_WEBGL || UNITY_EDITOR
        if (websocket != null)
            websocket.DispatchMessageQueue();
#endif
    }

    async void OnDestroy()
    {
        if (websocket != null)
            await websocket.Close();
    }
}