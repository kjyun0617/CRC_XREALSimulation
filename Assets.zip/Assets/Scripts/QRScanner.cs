using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ZXing;

public class QRScanner : MonoBehaviour
{
    public delegate void FNotifyDetectorNameSignature(string inText);
    public static event FNotifyDetectorNameSignature OnQRDetected;

    public List<string> detectorNameList = new List<string>();
    private WebCamTexture camTexture;
    private bool isScanning = false;

    void Start()
    {
        Debug.Log("QRScanner Start 호출됨");
        StartCoroutine(RequestCameraAndStart());
    }

    IEnumerator RequestCameraAndStart()
    {
        Debug.Log("카메라 권한 요청 중...");
        // 런타임 카메라 퍼미션 요청
        yield return Application.RequestUserAuthorization(UserAuthorization.WebCam);

        if (Application.HasUserAuthorization(UserAuthorization.WebCam))
        {
            Debug.Log("카메라 권한 허용됨");
            StartCamera();
        }
        else
        {
            Debug.LogError("카메라 권한 거부됨!");
        }
    }

    void StartCamera()
    {
        WebCamDevice[] devices = WebCamTexture.devices;
        if (devices.Length == 0)
        {
            Debug.LogError("카메라 없음");
            return;
        }

        // 후면 카메라 찾기
        string camName = devices[0].name;
        foreach (var d in devices)
        {
            if (!d.isFrontFacing)
            {
                camName = d.name;
                break;
            }
        }

        camTexture = new WebCamTexture(camName, 1280, 720);
        camTexture.Play();
        isScanning = true;
        StartCoroutine(ScanLoop());
        Debug.Log($"카메라 시작: {camName}");
    }

    IEnumerator ScanLoop()
    {
        while (isScanning)
        {
            yield return new WaitForSeconds(0.5f);
            ScanFrame();
        }
    }

    void ScanFrame()
    {
        if (camTexture == null || !camTexture.isPlaying) return;
        if (camTexture.width < 100) return; // 아직 초기화 안 된 경우

        try
        {
            var pixels = camTexture.GetPixels32();
            var bytes = new byte[pixels.Length * 4];
            for (int i = 0; i < pixels.Length; i++)
            {
                bytes[i * 4] = pixels[i].r;
                bytes[i * 4 + 1] = pixels[i].g;
                bytes[i * 4 + 2] = pixels[i].b;
                bytes[i * 4 + 3] = pixels[i].a;
            }

            var source = new RGBLuminanceSource(bytes, camTexture.width, camTexture.height, RGBLuminanceSource.BitmapFormat.RGBA32);
            var binarizer = new ZXing.Common.HybridBinarizer(source);
            var bitmap = new ZXing.BinaryBitmap(binarizer);
            var reader = new ZXing.QrCode.QRCodeReader();
            var result = reader.decode(bitmap);

            if (result == null) return;
            if (detectorNameList.Contains(result.Text)) return;

            Debug.Log($"QR 인식: {result.Text}");
            OnQRDetected?.Invoke(result.Text);
            detectorNameList.Add(result.Text);
        }
        catch (System.Exception e)
        {
            Debug.LogError($"스캔 에러: {e.Message}");
        }
    }

    void OnDestroy()
    {
        isScanning = false;
        if (camTexture != null) camTexture.Stop();
    }
}